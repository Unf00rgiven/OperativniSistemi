/*
Napraviti konkurentni program u kom se u funkciji niti pravi veliki niz od 1000000000000 elemenata.
Niz se pravi dinamicki. Kreiranje niza zastititi try - catch blokom. U okviru try catch bloka zakljucati
mutex pre pravljenja niza i otkljucati ga nakon pravljenja niza. Posmatrati ponasanje programa.

Nakon toga promeniti kod tako da se ne zakljucava mutex eksplicitno vec da se koristi klasa unique_lock.
*/


